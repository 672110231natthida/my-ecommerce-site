// backend/routes/register.js
const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

const userDataPath = path.join(__dirname, "../data/user.json");

// POST /api/register
router.post("/", (req, res) => {
  try {
    const { fname, lname, email, password, category, occupation } = req.body;

    if (!fname || !lname || !email || !password || !category || !occupation) {
      return res.status(400).send("Missing required fields.");
    }

    let users = [];
    if (fs.existsSync(userDataPath)) {
      const fileContent = fs.readFileSync(userDataPath, "utf-8");
      users = JSON.parse(fileContent);
    }

    const isEmailUsed = users.some(user => user.email === email);
    if (isEmailUsed) {
      return res.status(400).send("This email has already been used.");
    }

    users.push({ fname, lname, email, password, category, occupation });

    fs.writeFileSync(userDataPath, JSON.stringify(users, null, 2));
    res.send("Register successfully");
    
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
