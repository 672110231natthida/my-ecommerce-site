const express = require('express');
const router = express.Router();

router.post('/', (req, res) => {
    const { fname, lname, email, subject, message } = req.body;

    if (!fname || !lname || !email || !subject || !message) {
        return res.status(400).json({ error: 'Please fill out all required fields.' });
    }
    console.log('Content from sumited', { fname, lname, email, subject, message });
    res.status(200).json({ status: 'Message Received' });
});

module.exports = router;